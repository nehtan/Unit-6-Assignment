/* 
 * May 14, 2024
 * Question class
 */
package hussaineverrittprojectmanagement;

/**
 *
 * @author ZaHus7160
 */
public class Question {
    
    public String question, posAnswer1, posAnswer2, posAnswer3, posAnswer4, rightAns, feedback;
    public int mark;
    
    /**
     * 
     * @param q
     * @param pa1
     * @param pa2
     * @param pa3
     * @param pa4
     * @param ra 
     */
    public Question(String q, String pa1, String pa2, String pa3, String pa4, String ra){
        question = q;
        posAnswer1 = pa1;
        posAnswer2 = pa2;
        posAnswer3 = pa3;
        posAnswer4 = pa4;
        rightAns = ra;
    }
    /**
     * 
     * @param q
     * @param pa1
     * @param pa2
     * @param pa3
     * @param pa4
     * @param ra
     * @param f 
     */
    public Question(String q, String pa1, String pa2, String pa3, String pa4, String ra, String f){
        this(q, pa1, pa2, pa3, pa4, ra);
        feedback = f;
    }
    /**
     * 
     * @return 
     */
    public int getMark(){
        return mark;
    }
    /**
     * 
     * @param m 
     */
    public void setMark(int m){
        mark = m;
    }
    /**
     * 
     * @return 
     */
    public String getQuestion(){
        return question;
    }
    /**
     * 
     * @param q 
     */
    public void setQuestion(String q){
        question = q;
    }
    /**
     * 
     * @return 
     */
    public String getPosAnswer1(){
        return posAnswer1;
    }
    /**
     * 
     * @param pa1 
     */
    public void setPosAnswer1(String pa1){
        posAnswer1 = pa1;
    }
    /**
     * 
     * @return 
     */
    public String getPosAnswer2(){
        return posAnswer2;
    }
    /**
     * 
     * @param pa2 
     */
    public void setPosAnswer2(String pa2){
        posAnswer2 = pa2;
    }
    /**
     * 
     * @return 
     */
    public String getPosAnswer3(){
        return posAnswer3;
    }
    /**
     * 
     * @param pa3 
     */
    public void setPosAnswer3(String pa3){
        posAnswer3 = pa3;
    }
    /**
     * 
     * @return 
     */
    public String getPosAnswer4(){
        return posAnswer4;
    }
    /**
     * 
     * @param pa4 
     */
    public void setPosAnswer4(String pa4){
        posAnswer4 = pa4;
    }
    /**
     * 
     * @return 
     */
    public String getRightAns(){
        return rightAns;
    }
    /**
     * 
     * @param ra 
     */
    public void setRightAns(String ra){
        rightAns = ra;
    }
    /**
     * 
     * @return 
     */
    public String getFeedback(){
        return feedback;
    }
    /**
     * 
     * @param f 
     */
    public void setFeedback(String f){
        feedback = f;
    }

    @Override
    /**
     * 
     */
    public String toString() {
        return "Question{" + "question=" + question + ", posAnswer1=" + posAnswer1 + ", posAnswer2=" + posAnswer2 + ", posAnswer3=" + posAnswer3 + ", posAnswer4=" + posAnswer4 + ", rightAns=" + rightAns + ", feedback=" + feedback + ", mark=" + mark + '}';
    }
    
    
}
